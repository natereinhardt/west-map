class Point { // basic class for storing points with x and y positions
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
}