//Basic vector class because I don't want to spend 8 seconds google searching the built-in one
class Vector {
    constructor(x, y) {
        this.x = x; this.y = y;
    }
}